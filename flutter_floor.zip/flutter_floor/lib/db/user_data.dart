

import 'package:floor/floor.dart';

@entity
class UserData{

  @primaryKey
  final int? id;
  final String name;
  final String phone;
  UserData({this.id, required this.name, required this.phone});

}