package com.example.flutter_floor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
